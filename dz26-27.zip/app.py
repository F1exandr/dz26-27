from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from forms import LoginForm, RegistrationForm, TaskForm
from models import TMSDB, db

# Создание приложения Flask
app = Flask(__name__)

# Конфигурация ключа для шифрования данных
app.config['SECRET_KEY'] = 'taskmanagementsystemsecret'

# Конфигурация подключения к базе данных PostgreSQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost:5433/task_manager'

# Отключение отслеживания изменений в базе данных
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Инициализация базы данных
db.init_app(app)

# Создание таблиц в базе данных
with app.app_context():
    db.create_all()
    db.session.commit()

# Конфигурация менеджера логина
login_manager = LoginManager(app)
login_manager.login_view = 'login'


# Функция для загрузки пользователя по идентификатору
@login_manager.user_loader
def load_user(user_id):
    return TMSDB.User.query.get(user_id)


# Маршрут для главной страницы
@app.route('/')
def index():
    return render_template('index.html')


# Маршрут для страницы логина
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Создание формы логина
    form = LoginForm()

    # Обработка формы логина
    if request.method == 'POST':
        if form.validate_on_submit():
            # Поиск пользователя по email
            user = TMSDB.User.query.filter_by(email=form.email.data).first()

            # Проверка пароля
            if user and check_password_hash(user.password, form.password.data):
                # Логин пользователя
                login_user(user)
                return redirect(url_for('dashboard'))
            else:
                # Вывод ошибки
                flash('Неверный логин или пароль', 'danger')
        else:
            # Вывод ошибки
            flash('Некорректно введены данные', 'danger')

    # Рендеринг страницы логина
    return render_template('login.html', form=form)


# Маршрут для страницы регистрации
@app.route('/register', methods=['GET', 'POST'])
def register():
    # Создание формы регистрации
    form = RegistrationForm()

    # Обработка формы регистрации
    if request.method == 'POST':
        if form.validate_on_submit():
            # Создание нового пользователя
            hashed_password = generate_password_hash(form.password.data)
            new_user = TMSDB.User(username=form.username.data,
                                  email=form.email.data,
                                  password=hashed_password)

            # Добавление пользователя в базу данных
            db.session.add(new_user)
            db.session.commit()

            # Перенаправление на страницу логина
            return redirect(url_for('login'))
        else:
            # Вывод ошибки
            flash('Некорректно введены данные', 'danger')

    # Рендеринг страницы регистрации
    return render_template('register.html', form=form)


# Маршрут для страницы задач
@app.route('/dashboard')
@login_required
def dashboard():
    # Получение задач пользователя
    tasks = TMSDB.Task.query.filter_by(user_id=current_user.id).all()

    # Рендеринг страницы задач
    return render_template('dashboard.html', tasks=tasks)


# Маршрут для создания новой задачи
@app.route('/task/new', methods=['GET', 'POST'])
@login_required
def new_task():
    # Создание формы задачи
    form = TaskForm()

    # Обработка формы задачи
    if request.method == 'POST':
        if form.validate_on_submit():
            # Создание новой задачи
            task = TMSDB.Task(title=form.title.data,
                              description=form.description.data,
                              status=form.status.data,
                              user_id=current_user.id)

            # Добавление задачи в базу данных
            db.session.add(task)
            db.session.commit()

            # Вывод сообщения об успехе
            flash('Задача создана', 'success')

            # Перенаправление на страницу задач
            return redirect(url_for('dashboard'))
        else:
            # Вывод ошибки
            flash('Некорректно введены данные', 'danger')

    # Рендеринг страницы создания задачи
    return render_template('task_form.html', form=form)

@app.route('/feedback', methods=['GET', 'POST'])
@login_required
def feedback():
    form = FeedbackForm()
    if form.validate_on_submit():
        feedback = TMSDB.Feedback(message=form.message.data, user_id=current_user.id)
        db.session.add(feedback)
        db.session.commit()
        flash('Feedback submitted', 'success')
        return redirect(url_for('feedback'))
    return render_template('feedback.html', form=form)

@app.route('/feedback/list')
@login_required
def feedback_list():
    feedbacks = TMSDB.Feedback.query.all()
    return render_template('feedback_list.html', feedbacks=feedbacks)

# Маршрут для редактирования задачи
@app.route('/task/edit/<int:task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
# Получение задачи по идентификатору
